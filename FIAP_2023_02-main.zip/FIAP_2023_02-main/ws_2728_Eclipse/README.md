# Referente ao problema com o seed do banco de dados.

Na versão do Eclipse utilizado no laboratório, o nome do arquivo precisa ser `data.sql` e ***não import.sql***.

Eu havia comentando em sala de aula sobre esse problema.

No **Spring Tool Suite** o nome do arquivo é `import.sql`

No IntelliJ versão 2023.1.3 tenho utilizado o arquivo com o nome `import.sql` e não apresenta problema.

Bons estudos.

Profa. Cida