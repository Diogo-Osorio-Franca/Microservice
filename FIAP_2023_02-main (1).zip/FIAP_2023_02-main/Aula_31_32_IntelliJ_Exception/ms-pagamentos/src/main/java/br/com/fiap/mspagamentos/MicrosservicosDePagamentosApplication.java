package br.com.fiap.mspagamentos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicrosservicosDePagamentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicrosservicosDePagamentosApplication.class, args);
	}

}
