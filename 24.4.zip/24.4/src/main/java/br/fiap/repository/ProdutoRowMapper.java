package br.fiap.repository;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;

import br.com.fiap.model.ModelCategoria;
import br.com.fiap.model.ModelProduto;
import br.com.fiap.model.ModelMarca;

public class ProdutoRowMapper implements RowMapper<ModelProduto> {

	@Override
	public ModelProduto mapRow(ResultSet rs, int rowNum) throws SQLException {

		ModelProduto ModelProduto = new BeanPropertyRowMapper<>(ModelProduto.class).mapRow(rs, rowNum);
		ModelCategoria ModelCategoria = new BeanPropertyRowMapper<>(ModelCategoria.class).mapRow(rs, rowNum);
		ModelMarca ModelMarca = new BeanPropertyRowMapper<>(ModelMarca.class).mapRow(rs, rowNum);
		
		ModelProduto.setCategoria(ModelCategoria);
		ModelProduto.setMarca(ModelMarca);
		
		return ModelProduto;
	}

}
