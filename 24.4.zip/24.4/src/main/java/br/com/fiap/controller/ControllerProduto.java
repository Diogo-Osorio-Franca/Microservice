package br.com.fiap.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.fiap.model.ModelProduto;
import br.com.fiap.repository.RepositoryCategoria;
import br.com.fiap.repository.RepositoryLoja;
import br.com.fiap.repository.RepositoryMarca;
import br.com.fiap.repository.RepositoryProduto;

@Controller
@RequestMapping("/produtos")
public class ControllerProduto {

	@Autowired
	RepositoryProduto repository;
	@Autowired
	RepositoryCategoria categoriaRepository;
	@Autowired
	RepositoryMarca marcaRepository;
	@Autowired
	RepositoryLoja lojaRepository;
	
	
	private static final String PRODUTO_FOLDER = "produto/";

	@GetMapping
	public String findAll(Model model) {
		model.addAttribute("produtos", repository.findAll());
		return PRODUTO_FOLDER+"produtos";
	}

	@GetMapping("/form")
	public String open(@RequestParam("page") String page, @RequestParam(required = false) Long id,
			@ModelAttribute("ModelProduto") ModelProduto ModelProduto, Model model) {

		if ("produto-editar".equals(page))
			model.addAttribute("ModelProduto", repository.findById(id));
		
		model.addAttribute("categorias", categoriaRepository.findAll());
		
		model.addAttribute("lojas", lojaRepository.findAll());
		
		model.addAttribute("marcas", marcaRepository.findAll());

		return PRODUTO_FOLDER+page;
	}

	@GetMapping("/{id}")
	public String findById(@PathVariable("id") long id, Model model) {
		model.addAttribute("produto", repository.findById(id).get());
		return PRODUTO_FOLDER+"produto-detalhe";
	}

	@PostMapping
	public String save(@Valid ModelProduto produto, BindingResult bindingResult,
			RedirectAttributes redirectAttributes) {
		if (bindingResult.hasErrors()) 
			return PRODUTO_FOLDER+"produto-novo";

		repository.save(produto);
		redirectAttributes.addFlashAttribute("messages", "Produto cadastrado com sucesso!");
		return "redirect:/produtos";
	}
	
	@PutMapping("/{id}")
	public String update(@PathVariable("id") long id, Model model, @Valid ModelProduto ModelProduto,
			RedirectAttributes redirectAttributes) {
		ModelProduto.setId(id);
		repository.save(ModelProduto);
		redirectAttributes.addFlashAttribute("messages", "Produto atualizado com sucesso!");
		model.addAttribute("produtos", repository.findAll());
		return "redirect:/produtos";
	}

	@DeleteMapping("/{id}")
	public String delete(@PathVariable("id") long id, Model model, RedirectAttributes redirectAttributes) {
		repository.deleteById(id);
		redirectAttributes.addFlashAttribute("messages", "Produto excluído com sucesso!");
		model.addAttribute("produtos", repository.findAll());
		return "redirect:/produtos";
	}

}
