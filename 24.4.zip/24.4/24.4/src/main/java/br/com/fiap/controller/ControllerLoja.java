package br.com.fiap.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.fiap.model.ModelLoja;
import br.com.fiap.repository.RepositoryLoja;

@Controller
@RequestMapping("/lojas")
public class ControllerLoja {

	private static final String LOJA_FOLDER = "loja/";
	
	@Autowired
	public RepositoryLoja repository;
	
	@GetMapping
	public String findAll(Model model) {
		model.addAttribute("lojas", repository.findAll());
		return LOJA_FOLDER+"lojas";
	}
	
	@GetMapping("/form")
	public String open(@RequestParam("page") String page, @RequestParam(required = false) Long id,
			@ModelAttribute("ModelLoja") ModelLoja ModelLoja, Model model) {
		if ("loja-editar".equals(page)) 
			model.addAttribute("ModelLoja", repository.findById(id).get());

		return LOJA_FOLDER+page;
	}
	
	@GetMapping("/{id}")
	public String findById(@PathVariable("id") Long id, Model model) {
		model.addAttribute("loja", repository.findById(id).get());
		return LOJA_FOLDER+"loja-detalhe";
	}
	
	@PostMapping
	public String save(@Valid ModelLoja ModelLoja, BindingResult bindingResult,
			RedirectAttributes redirectAttributes) {
		if (bindingResult.hasErrors()) 
			return LOJA_FOLDER+"loja-novo";

		repository.save(ModelLoja);
		redirectAttributes.addFlashAttribute("messages", "loja cadastrada com sucesso!");
		return "redirect:/lojas";
	}

	@PutMapping("/{id}")
	public String update(@PathVariable("id") Long id, @Valid ModelLoja ModelLoja, Model model,
			RedirectAttributes redirectAttributes) {
		ModelLoja.setIdLoja(id);
		repository.save(ModelLoja);
		redirectAttributes.addFlashAttribute("messages", "loja atualizada com sucesso!");
		model.addAttribute("lojas", repository.findAll());
		return "redirect:/lojas";
	}
	
	@DeleteMapping("/{id}")
	public String delete(@PathVariable("id") Long id, Model model, RedirectAttributes redirectAttributes) {
		repository.deleteById(id);
		redirectAttributes.addFlashAttribute("messages", "loja excluída com sucesso!");
		model.addAttribute("lojas", repository.findAll());
		return "redirect:/lojas";
	}
}