package br.com.fiap.model;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "TB_MARCA")
public class ModelMarca {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_MARCA")
	private Long idMarca;
	
	@Column(name = "NOME_MARCA")
	private String nomeMarca;
	
	@OneToMany(mappedBy = "marca")
	private List<ModelProduto> produtos;
	public Long getIdMarca() {
		return idMarca;
	}
	public void setIdMarca(long idMarca) {
		this.idMarca = idMarca;
	}
	public String getNomeMarca() {
		return nomeMarca;
	}
	public ModelMarca(Long idMarca, String nomeMarca, List<ModelProduto> produtos) {
		super();
		this.idMarca = idMarca;
		this.nomeMarca = nomeMarca;
		this.produtos = produtos;
	}
	public void setNomeMarca(String nomeMarca) {
		this.nomeMarca = nomeMarca;
	}
	public ModelMarca() {
		super();
	}
	
	
}
